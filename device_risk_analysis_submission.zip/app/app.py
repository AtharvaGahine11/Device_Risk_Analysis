"""
Device Risk Analysis - Interactive Streamlit Web Application
Case Study No. 86 | ITM SKILLS UNIVERSITY (School of Future Tech)
Author: Sanchita Suryawanshi (B.Tech CSE Semester V, 2024-2028)
"""

import os
import joblib
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

# Set page configuration
st.set_page_config(
    page_title="Device Risk Analysis | ITM Skills University",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Light Modern Styling
st.markdown("""
<style>
    /* Global styling */
    .main {
        background-color: #f8fafc;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }
    
    /* Header & Titles */
    h1, h2, h3 {
        color: #0f172a;
        font-weight: 700;
    }
    
    /* KPI Metric Cards */
    .kpi-card {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        padding: 16px 20px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        text-align: center;
        margin-bottom: 12px;
    }
    .kpi-title {
        font-size: 0.82rem;
        color: #64748b;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .kpi-value {
        font-size: 1.65rem;
        font-weight: 700;
        margin-top: 4px;
        color: #0f172a;
    }
    .kpi-badge {
        font-size: 0.75rem;
        padding: 3px 8px;
        border-radius: 9999px;
        display: inline-block;
        margin-top: 4px;
        font-weight: 600;
    }
    
    /* Risk Badges */
    .badge-low { background-color: #dcfce7; color: #15803d; }
    .badge-medium { background-color: #fef3c7; color: #b45309; }
    .badge-high { background-color: #fee2e2; color: #b91c1c; }
    
    /* Result Card */
    .result-container {
        border-radius: 12px;
        padding: 24px;
        margin-top: 18px;
        margin-bottom: 24px;
        border: 2px solid;
    }
    .res-low {
        background-color: #f0fdf4;
        border-color: #86efac;
        color: #14532d;
    }
    .res-med {
        background-color: #fffbeb;
        border-color: #fde68a;
        color: #78350f;
    }
    .res-high {
        background-color: #fef2f2;
        border-color: #fca5a5;
        color: #7f1d1d;
    }
    
    /* Sidebar adjustments */
    section[data-testid="stSidebar"] {
        background-color: #ffffff;
        border-right: 1px solid #e2e8f0;
    }
    
    /* Button enhancement */
    div.stButton > button:first-child {
        background-color: #2563eb;
        color: white;
        font-weight: 600;
        border-radius: 8px;
        padding: 10px 24px;
        border: none;
        transition: all 0.2s ease;
    }
    div.stButton > button:first-child:hover {
        background-color: #1d4ed8;
        color: white;
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.2);
    }
</style>
""", unsafe_allow_html=True)

# Helper function to load cached model and metadata
@st.cache_resource
def load_model_artifacts():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    model_path = os.path.join(base_dir, "models", "best_model.pkl")
    meta_path = os.path.join(base_dir, "models", "model_metadata.pkl")
    
    if not os.path.exists(model_path):
        # Fallback to local relative path
        model_path = "models/best_model.pkl"
        meta_path = "models/model_metadata.pkl"
        
    if not os.path.exists(model_path):
        return None, None
        
    model = joblib.load(model_path)
    metadata = joblib.load(meta_path) if os.path.exists(meta_path) else None
    return model, metadata

@st.cache_data
def load_datasets():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    processed_path = os.path.join(base_dir, "data", "processed", "device_risk_processed.csv")
    results_path = os.path.join(base_dir, "outputs", "model_results.csv")
    feat_imp_path = os.path.join(base_dir, "outputs", "feature_importance.csv")
    
    # Fallback to relative
    if not os.path.exists(processed_path):
        processed_path = "data/processed/device_risk_processed.csv"
        results_path = "outputs/model_results.csv"
        feat_imp_path = "outputs/feature_importance.csv"
        
    df_proc = pd.read_csv(processed_path) if os.path.exists(processed_path) else None
    df_results = pd.read_csv(results_path) if os.path.exists(results_path) else None
    df_feat_imp = pd.read_csv(feat_imp_path) if os.path.exists(feat_imp_path) else None
    
    return df_proc, df_results, df_feat_imp

# Load resources
model_pipeline, metadata = load_model_artifacts()
df_proc, df_results, df_feat_imp = load_datasets()

# -----------------------------------------------------------------------------
# SIDEBAR
# -----------------------------------------------------------------------------
with st.sidebar:
    # Display logo if available
    logo_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "logo.png")
    if not os.path.exists(logo_path):
        logo_path = "assets/logo.png"
    if os.path.exists(logo_path):
        st.image(logo_path, width=80)
        
    st.title("Device Risk Analysis")
    st.caption("AI-Powered Endpoint Security Classification")
    st.markdown("---")
    
    menu = [
        "🏠 1. Home",
        "🔍 2. Risk Prediction",
        "📊 3. Dataset Insights",
        "📈 4. Model Performance",
        "🛡️ 5. Security Insights",
        "ℹ️ 6. About Project"
    ]
    choice = st.radio("Navigation Menu", menu, index=0)
    
    st.markdown("---")
    st.markdown("""
    **Academic Case Study No. 86**  
    *ITM SKILLS UNIVERSITY*  
    **Student:** Sanchita Suryawanshi  
    **Program:** B.Tech CSE (Sem V)  
    **Year:** 2024–2028
    """)

# -----------------------------------------------------------------------------
# 1. HOME PAGE
# -----------------------------------------------------------------------------
if choice == "🏠 1. Home":
    st.title("🛡️ DEVICE RISK ANALYSIS")
    st.subheader("Machine Learning Based Device Security Risk Prediction")
    st.markdown("""
    This system applies supervised machine learning classification to enterprise device telemetry. 
    By analyzing multi-dimensional endpoint attributes—including firmware age, unpatched CVEs, 
    failed login spikes, open ports, and protection status—the system categorizes endpoints into 
    **Low Risk**, **Medium Risk**, and **High Risk** tiers to empower rapid cybersecurity triage.
    """)
    
    st.markdown("---")
    
    # KPI Summary Cards
    col1, col2, col3, col4, col5 = st.columns(5)
    
    total_dev = len(df_proc) if df_proc is not None else 3000
    low_dev = (df_proc['Risk_Level'] == 'Low Risk').sum() if df_proc is not None else 964
    med_dev = (df_proc['Risk_Level'] == 'Medium Risk').sum() if df_proc is not None else 1264
    high_dev = (df_proc['Risk_Level'] == 'High Risk').sum() if df_proc is not None else 772
    best_acc = f"{metadata.get('test_accuracy', 0.89)*100:.2f}%" if metadata else "89.00%"
    
    with col1:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-title">Total Fleet</div>
            <div class="kpi-value">{total_dev:,}</div>
            <div class="kpi-badge" style="background:#e0f2fe; color:#0369a1;">Endpoints</div>
        </div>
        """, unsafe_allow_html=True)
        
    with col2:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-title">Low Risk</div>
            <div class="kpi-value" style="color:#16a34a;">{low_dev:,}</div>
            <div class="kpi-badge badge-low">{low_dev/total_dev*100:.1f}% of total</div>
        </div>
        """, unsafe_allow_html=True)
        
    with col3:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-title">Medium Risk</div>
            <div class="kpi-value" style="color:#d97706;">{med_dev:,}</div>
            <div class="kpi-badge badge-medium">{med_dev/total_dev*100:.1f}% of total</div>
        </div>
        """, unsafe_allow_html=True)
        
    with col4:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-title">High Risk</div>
            <div class="kpi-value" style="color:#dc2626;">{high_dev:,}</div>
            <div class="kpi-badge badge-high">{high_dev/total_dev*100:.1f}% of total</div>
        </div>
        """, unsafe_allow_html=True)
        
    with col5:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-title">Champion Accuracy</div>
            <div class="kpi-value" style="color:#2563eb;">{best_acc}</div>
            <div class="kpi-badge" style="background:#ede9fe; color:#6d28d9;">Logistic Reg. (Tuned)</div>
        </div>
        """, unsafe_allow_html=True)
        
    st.markdown("### 🏗️ Machine Learning Architecture Workflow")
    workflow_fig = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs", "figures", "11_ml_architecture_workflow.png")
    if not os.path.exists(workflow_fig):
        workflow_fig = "outputs/figures/11_ml_architecture_workflow.png"
    if os.path.exists(workflow_fig):
        st.image(workflow_fig, caption="End-to-End Supervised Classification Pipeline Architecture", use_container_width=True)

# -----------------------------------------------------------------------------
# 2. RISK PREDICTION
# -----------------------------------------------------------------------------
elif choice == "🔍 2. Risk Prediction":
    st.title("🔍 Interactive Device Risk Prediction")
    st.markdown("Input device parameters to evaluate security risk level using the trained champion classifier.")
    
    if model_pipeline is None:
        st.error("⚠️ Trained model artifact (`best_model.pkl`) not found. Please run `scripts/train_and_evaluate.py` first.")
    else:
        # Pre-fill with sample presets
        preset = st.selectbox("⚡ Quick Pre-fill Template", [
            "Custom Input",
            "Template 1: Secure Developer Laptop (Expected: Low Risk)",
            "Template 2: Departmental Desktop with Pending Updates (Expected: Medium Risk)",
            "Template 3: Misconfigured Field IoT Gateway (Expected: High Risk)"
        ])
        
        # Default values
        defaults = {
            'type': 'Laptop', 'os': 'Windows 11', 'age': 12, 'fw_age': 3,
            'logins': 2, 'ports': 3, 'vulns': 1, 'updates': 1, 'enc': 'Yes',
            'av': 'Active', 'susp': 0, 'traffic': 650.0, 'access': 5.0,
            'incidents': 0, 'patch': 'Fully Patched'
        }
        
        if preset == "Template 1: Secure Developer Laptop (Expected: Low Risk)":
            defaults = {
                'type': 'Laptop', 'os': 'Windows 11', 'age': 8, 'fw_age': 2,
                'logins': 1, 'ports': 2, 'vulns': 0, 'updates': 0, 'enc': 'Yes',
                'av': 'Active', 'susp': 0, 'traffic': 420.0, 'access': 4.5,
                'incidents': 0, 'patch': 'Fully Patched'
            }
        elif preset == "Template 2: Departmental Desktop with Pending Updates (Expected: Medium Risk)":
            defaults = {
                'type': 'Desktop', 'os': 'Windows 10', 'age': 36, 'fw_age': 14,
                'logins': 5, 'ports': 5, 'vulns': 4, 'updates': 3, 'enc': 'Yes',
                'av': 'Outdated', 'susp': 1, 'traffic': 1200.0, 'access': 6.2,
                'incidents': 1, 'patch': 'Partially Patched'
            }
        elif preset == "Template 3: Misconfigured Field IoT Gateway (Expected: High Risk)":
            defaults = {
                'type': 'IoT_Gateway', 'os': 'Embedded Linux', 'age': 58, 'fw_age': 28,
                'logins': 26, 'ports': 14, 'vulns': 12, 'updates': 8, 'enc': 'No',
                'av': 'Disabled', 'susp': 5, 'traffic': 3800.0, 'access': 8.5,
                'incidents': 3, 'patch': 'Outdated'
            }
            
        with st.form("risk_prediction_form"):
            st.markdown("#### 1. Hardware & System Identity")
            c1, c2, c3 = st.columns(3)
            with c1:
                dev_type = st.selectbox("Device Type", ['Laptop', 'Desktop', 'Server', 'Smartphone', 'IoT_Gateway', 'Tablet'],
                                        index=['Laptop', 'Desktop', 'Server', 'Smartphone', 'IoT_Gateway', 'Tablet'].index(defaults['type']))
            with c2:
                os_options = ['Windows 11', 'Windows 10', 'macOS', 'Ubuntu Linux', 'RedHat Linux', 'Android', 'Embedded Linux', 'Windows Server', 'iOS', 'iPadOS', 'FreeRTOS']
                os_idx = os_options.index(defaults['os']) if defaults['os'] in os_options else 0
                op_sys = st.selectbox("Operating System", os_options, index=os_idx)
            with c3:
                dev_age = st.slider("Device Age (Months)", 1, 72, defaults['age'])
                
            st.markdown("#### 2. Firmware, Network & Authentication Exposure")
            c4, c5, c6 = st.columns(3)
            with c4:
                fw_age = st.slider("Firmware Age (Months)", 0, 36, defaults['fw_age'])
                failed_logins = st.slider("Failed Logins (Past 30 Days)", 0, 50, defaults['logins'])
            with c5:
                open_ports = st.slider("Open Listening Ports", 1, 25, defaults['ports'])
                traffic_mb = st.number_input("Average Daily Traffic (MB)", 50.0, 15000.0, float(defaults['traffic']), step=100.0)
            with c6:
                access_freq = st.slider("Access Frequency Score", 1.0, 10.0, float(defaults['access']), step=0.1)
                susp_flags = st.slider("Suspicious Activity Alerts", 0, 10, defaults['susp'])
                
            st.markdown("#### 3. Vulnerability & Defense Posture")
            c7, c8, c9 = st.columns(3)
            with c7:
                vulns = st.slider("Unpatched CVE Vulnerabilities", 0, 20, defaults['vulns'])
                updates = st.slider("Security Updates Pending", 0, 15, defaults['updates'])
            with c8:
                encryption = st.selectbox("Disk Encryption Enabled", ['Yes', 'No'],
                                          index=['Yes', 'No'].index(defaults['enc']))
                antivirus = st.selectbox("Antivirus Status", ['Active', 'Outdated', 'Disabled'],
                                         index=['Active', 'Outdated', 'Disabled'].index(defaults['av']))
            with c9:
                patch_status = st.selectbox("Patch Compliance Status", ['Fully Patched', 'Partially Patched', 'Outdated'],
                                            index=['Fully Patched', 'Partially Patched', 'Outdated'].index(defaults['patch']))
                past_incidents = st.slider("Past Security Incidents", 0, 5, defaults['incidents'])
                
            submitted = st.form_submit_button("🛡️ PREDICT DEVICE RISK LEVEL")
            
        if submitted:
            # Feature Engineering calculations
            vf_ratio = round(vulns / (fw_age + 1), 3)
            attack_surface = round((open_ports * 0.4) + (failed_logins * 0.6), 2)
            
            comp = 10.0
            comp -= (updates * 0.5)
            comp -= (2.5 if encryption == 'No' else 0.0)
            comp -= (3.5 if antivirus == 'Disabled' else (1.5 if antivirus == 'Outdated' else 0.0))
            comp_score = float(np.clip(round(comp, 2), 0.0, 10.0))
            
            input_df = pd.DataFrame([{
                'Device_Type': dev_type,
                'Operating_System': op_sys,
                'Device_Age_Months': dev_age,
                'Firmware_Age_Months': fw_age,
                'Failed_Login_Attempts': failed_logins,
                'Open_Ports_Count': open_ports,
                'Vulnerability_Count': vulns,
                'Security_Updates_Pending': updates,
                'Encryption_Enabled': encryption,
                'Antivirus_Status': antivirus,
                'Suspicious_Activity_Flags': susp_flags,
                'Average_Daily_Traffic_MB': traffic_mb,
                'Access_Frequency_Score': access_freq,
                'Previous_Security_Incidents': past_incidents,
                'Patch_Status': patch_status,
                'Vulnerability_Firmware_Ratio': vf_ratio,
                'Attack_Surface_Index': attack_surface,
                'Compliance_Posture_Score': comp_score
            }])
            
            # Predict
            pred_code = model_pipeline.predict(input_df)[0]
            probs = model_pipeline.predict_proba(input_df)[0]
            class_names = ['Low Risk', 'Medium Risk', 'High Risk']
            pred_label = class_names[pred_code]
            
            # Display Result
            badge_class = "res-low" if pred_label == "Low Risk" else ("res-med" if pred_label == "Medium Risk" else "res-high")
            icon = "✅" if pred_label == "Low Risk" else ("⚠️" if pred_label == "Medium Risk" else "🚨")
            
            st.markdown(f"""
            <div class="result-container {badge_class}">
                <div style="font-size: 1.1rem; font-weight: 600;">Prediction Output:</div>
                <h2 style="margin: 6px 0; font-size: 2.2rem;">{icon} {pred_label}</h2>
                <p style="margin: 0; font-size: 0.95rem;">
                    The endpoint has been classified into the <b>{pred_label}</b> security category based on its composite vulnerability, authentication, and endpoint defense profile.
                </p>
            </div>
            """, unsafe_allow_html=True)
            
            # Confidence Metrics
            st.markdown("#### Prediction Confidence Breakdown")
            p_col1, p_col2, p_col3 = st.columns(3)
            p_col1.metric("Low Risk Probability", f"{probs[0]*100:.1f}%")
            p_col2.metric("Medium Risk Probability", f"{probs[1]*100:.1f}%")
            p_col3.metric("High Risk Probability", f"{probs[2]*100:.1f}%")
            
            st.markdown("---")
            
            # Domain Recommendations based on prediction
            st.markdown("#### 🛠️ Recommended Administrative Actions")
            if pred_label == "Low Risk":
                st.success("""
                - **Status Healthy:** Device adheres to security compliance standards.
                - **Action:** Maintain routine scheduled patch monitoring and periodic compliance auditing.
                """)
            elif pred_label == "Medium Risk":
                st.warning("""
                - **Attention Needed:** Device exhibits elevated vulnerability or latency in updates.
                - **Action:** Apply pending OS security patches, update endpoint antivirus definitions, and audit listening ports.
                """)
            else:
                st.error("""
                - **Immediate Action Recommended:** Device presents acute vulnerability or active threat indicators.
                - **Action:** Isolate endpoint in a restricted quarantine VLAN, enable full-disk encryption, resolve critical CVEs, and reset credentials.
                """)
                
            with st.expander("🔍 View Processed Feature Vector"):
                st.dataframe(input_df)

# -----------------------------------------------------------------------------
# 3. DATASET INSIGHTS
# -----------------------------------------------------------------------------
elif choice == "📊 3. Dataset Insights":
    st.title("📊 Dataset Exploratory Analysis & Telemetry Insights")
    st.markdown("Detailed breakdown of the 3,000 endpoint records across security attributes.")
    
    if df_proc is not None:
        tab1, tab2, tab3 = st.tabs(["Fleet Distributions", "Security Factor Correlations", "Raw Telemetry Viewer"])
        
        with tab1:
            c1, c2 = st.columns(2)
            with c1:
                st.markdown("##### Target Class Balance (Risk_Level)")
                fig_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs", "figures", "01_risk_distribution.png")
                if not os.path.exists(fig_path):
                    fig_path = "outputs/figures/01_risk_distribution.png"
                if os.path.exists(fig_path):
                    st.image(fig_path, use_container_width=True)
                    
            with c2:
                st.markdown("##### Vulnerability Count Distribution Across Tiers")
                fig_path4 = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs", "figures", "04_vulnerabilities_by_risk.png")
                if not os.path.exists(fig_path4):
                    fig_path4 = "outputs/figures/04_vulnerabilities_by_risk.png"
                if os.path.exists(fig_path4):
                    st.image(fig_path4, use_container_width=True)
                    
            st.markdown("---")
            c3, c4 = st.columns(2)
            with c3:
                st.markdown("##### Endpoint Antivirus Protection vs Risk")
                fig_path5 = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs", "figures", "05_antivirus_vs_risk.png")
                if not os.path.exists(fig_path5):
                    fig_path5 = "outputs/figures/05_antivirus_vs_risk.png"
                if os.path.exists(fig_path5):
                    st.image(fig_path5, use_container_width=True)
                    
            with c4:
                st.markdown("##### Failed Authentication Login Spikes")
                fig_path6 = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs", "figures", "06_failed_logins_distribution.png")
                if not os.path.exists(fig_path6):
                    fig_path6 = "outputs/figures/06_failed_logins_distribution.png"
                if os.path.exists(fig_path6):
                    st.image(fig_path6, use_container_width=True)
                    
        with tab2:
            st.markdown("##### Pearson Correlation Heatmap")
            fig_path3 = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs", "figures", "03_correlation_heatmap.png")
            if not os.path.exists(fig_path3):
                fig_path3 = "outputs/figures/03_correlation_heatmap.png"
            if os.path.exists(fig_path3):
                st.image(fig_path3, use_container_width=True)
                
        with tab3:
            st.markdown("##### Processed Telemetry Records")
            st.dataframe(df_proc.head(100), use_container_width=True)
            st.caption(f"Displaying first 100 rows out of {len(df_proc)} records.")

# -----------------------------------------------------------------------------
# 4. MODEL PERFORMANCE
# -----------------------------------------------------------------------------
elif choice == "📈 4. Model Performance":
    st.title("📈 Machine Learning Model Benchmark & Evaluation")
    st.markdown("Rigorous comparison across six supervised multi-class classification algorithms.")
    
    if df_results is not None:
        st.markdown("### 🏆 Algorithm Comparison Table")
        st.dataframe(
            df_results.style.format({
                'Accuracy': '{:.4f}',
                'Precision': '{:.4f}',
                'Recall': '{:.4f}',
                'F1 Score': '{:.4f}',
                'ROC_AUC': '{:.4f}'
            }).highlight_max(subset=['Accuracy', 'F1 Score', 'ROC_AUC'], color='#dcfce7'),
            use_container_width=True
        )
        
        st.markdown("---")
        
        col_fig1, col_fig2 = st.columns(2)
        with col_fig1:
            st.markdown("##### Multi-Metric Comparison Chart")
            bar_fig = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs", "figures", "07_model_comparison_bar.png")
            if not os.path.exists(bar_fig):
                bar_fig = "outputs/figures/07_model_comparison_bar.png"
            if os.path.exists(bar_fig):
                st.image(bar_fig, use_container_width=True)
                
        with col_fig2:
            st.markdown("##### Confusion Matrix (Champion Model)")
            cm_fig = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs", "figures", "08_best_model_confusion_matrix.png")
            if not os.path.exists(cm_fig):
                cm_fig = "outputs/figures/08_best_model_confusion_matrix.png"
            if os.path.exists(cm_fig):
                st.image(cm_fig, use_container_width=True)
                
        st.markdown("---")
        st.markdown("##### Multi-Class One-vs-Rest (OvR) ROC Curves")
        roc_fig = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs", "figures", "10_multiclass_roc_curves.png")
        if not os.path.exists(roc_fig):
            roc_fig = "outputs/figures/10_multiclass_roc_curves.png"
        if os.path.exists(roc_fig):
            st.image(roc_fig, use_container_width=True)
    else:
        st.info("Run `scripts/train_and_evaluate.py` to generate model benchmark results.")

# -----------------------------------------------------------------------------
# 5. SECURITY INSIGHTS
# -----------------------------------------------------------------------------
elif choice == "🛡️ 5. Security Insights":
    st.title("🛡️ Feature Importance & Security Risk Drivers")
    st.markdown("""
    Model interpretability analysis reveals which telemetry attributes possess the strongest associations 
    with elevated device risk predictions.
    """)
    
    if df_feat_imp is not None:
        c1, c2 = st.columns([1, 1])
        with c1:
            st.markdown("##### Relative Feature Weights")
            st.dataframe(df_feat_imp.style.format({'Importance': '{:.4f}'}), use_container_width=True)
            
        with c2:
            st.markdown("##### Top 10 Risk Predictors")
            feat_fig = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs", "figures", "09_feature_importance.png")
            if not os.path.exists(feat_fig):
                feat_fig = "outputs/figures/09_feature_importance.png"
            if os.path.exists(feat_fig):
                st.image(feat_fig, use_container_width=True)
                
        st.markdown("---")
        st.markdown("### 💡 Key Findings for Security Teams")
        st.info("""
        1. **Operating System & Patch Management:** Operating system type, patch latency, and unpatched CVE count account for over 38% of overall predictive influence.
        2. **Perimeter & Authentication Exposure:** The engineered **Attack Surface Index** and failed authentication frequency provide early indicators of targeted brute-force activity.
        3. **Defense Configuration Posture:** Antivirus state and disk encryption directly regulate whether an endpoint resists or succumbs to lateral movement.
        """)

# -----------------------------------------------------------------------------
# 6. ABOUT PROJECT
# -----------------------------------------------------------------------------
elif choice == "ℹ️ 6. About Project":
    st.title("ℹ️ About the Project")
    st.markdown("""
    ### Project Identification
    * **Project Title:** DEVICE RISK ANALYSIS
    * **Academic Case Study Number:** Case Study No. 86
    * **Student Name:** Sanchita Suryawanshi
    * **Program:** B.Tech in Computer Science & Engineering
    * **Semester:** Semester V (Academic Year 2024–2028)
    * **University:** ITM SKILLS UNIVERSITY (School of Future Tech)
    * **Faculty Evaluation Course:** Machine Learning
    
    ---
    
    ### Academic Problem Statement
    > *"An organization wants to analyze device-related information and identify patterns associated with elevated security concerns."*
    
    ### Core Objectives
    - Analyze device telemetry and detect risk patterns.
    - Preprocess tabular data using scikit-learn standard pipelines.
    - Train and benchmark multiple ML classifiers (Logistic Regression, Decision Tree, Random Forest, KNN, SVM, Gradient Boosting).
    - Deploy an interactive Streamlit application for real-time risk assessment.
    
    ### Technology Stack
    - **Language:** Python 3.12
    - **Machine Learning:** Scikit-Learn, Joblib
    - **Data Processing:** Pandas, NumPy
    - **Visualization:** Matplotlib, Seaborn
    - **Web Framework:** Streamlit
    
    ### Ethical & Operational Disclaimers
    1. **Academic Decision Support:** Predictions generated by this system are statistical estimates intended to assist human security analysts, not replace human judgment.
    2. **No Offensive Cyber Instructions:** This application strictly provides defensive classification and risk assessment; it contains no offensive exploitation capabilities.
    3. **Model Retraining:** Endpoint security signatures drift over time as new threat patterns emerge; models must be periodically retrained on updated fleet telemetry.
    """)
